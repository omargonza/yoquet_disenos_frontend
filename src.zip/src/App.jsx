import { Routes, Route } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Productos from "./pages/Productos";
import ProductoDetalle from "./pages/ProductoDetalle";
import Carrito from "./pages/Carrito";
import CartButton from "./components/CartButton";
import Checkout from "./pages/Checkout";
import Confirmacion from "./pages/Confirmacion";
import Empaquetando from "./pages/Empaquetando";
import Despedida from "./components/Despedida";
import SplashScreen from "./components/SplashScreen";
import PageTransition from "./components/PageTransition";

import Register from "./pages/Register";
import ResetPasswordConfirm from "./pages/ResetPasswordConfirm";
import ResetPasswordRequest from "./pages/ResetPasswordRequest";
import ResetPassword from "./pages/ResetPassword";
import ForgotPassword from "./pages/ForgotPassword";
import ResetSuccess from "./pages/ResetSuccess";

import GestionPanel from "./pages/GestionPanel";

// PANEL ADMIN
import AdminDashboard from "./admin/pages/AdminDashboard";
import ProductosAdmin from "./admin/pages/ProductosAdmin";
import CategoriasAdmin from "./admin/pages/CategoriasAdmin";
import PedidosAdmin from "./admin/pages/PedidosAdmin";
import AdminLayout from "./admin/layout/AdminLayout";
import ProductoEditarAdmin from "./admin/pages/ProductoEditarAdmin";
import RequireAdmin from "./admin/components/RequireAdmin";

import { useAmbient } from "./context/AmbientContext";

export default function App() {
  const { theme, switchTheme, autoMode, setAutoMode } = useAmbient();
  const [showSplash, setShowSplash] = useState(true);

  const icons = {
    morning: "☀️",
    afternoon: "🌇",
    night: "🌙",
    festival: "🎉",
  };

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence mode="wait">
      {showSplash ? (
        <SplashScreen />
      ) : (
        <>
          <PageTransition>
            <Routes>

              {/* =============================== */}
              {/*             PUBLICO             */}
              {/* =============================== */}
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/productos" element={<Productos />} />
              <Route path="/productos/:id" element={<ProductoDetalle />} />
              <Route path="/carrito" element={<Carrito />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/confirmacion" element={<Confirmacion />} />
              <Route path="/empaquetando" element={<Empaquetando />} />
              <Route path="/despedida" element={<Despedida />} />

              {/* AUTH */}
              <Route path="/register" element={<Register />} />
              <Route path="/reset" element={<ResetPasswordRequest />} />
              <Route path="/reset-password/:uid/:token" element={<ResetPasswordConfirm />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-success" element={<ResetSuccess />} />

              {/* PANEL TÉCNICO */}
              <Route path="/gestion" element={<GestionPanel />} />

              {/* =============================== */}
              {/*           PANEL ADMIN           */}
              {/* =============================== */}
              <Route path="/admin" element={<RequireAdmin />}>
                <Route element={<AdminLayout />}>
                  <Route index element={<AdminDashboard />} />
                  <Route path="productos" element={<ProductosAdmin />} />
                  <Route path="productos/:id" element={<ProductoEditarAdmin />} />
                  <Route path="categorias" element={<CategoriasAdmin />} />
                  <Route path="pedidos" element={<PedidosAdmin />} />
                </Route>
              </Route>

            </Routes>
          </PageTransition>

          {/* =============================== */}
          {/* CARRITO + THEMES (no admin) */}
          {/* =============================== */}
          {!window.location.pathname.startsWith("/admin") && (
            <>
              <CartButton />

              <div
                className="fixed bottom-6 right-6 z-[999] flex items-center gap-3
                bg-white/20 backdrop-blur-md border border-white/30
                shadow-[0_4px_25px_rgba(255,216,90,0.3)]
                rounded-full px-3 py-2 transition-all duration-500"
              >
                <button
                  onClick={() => setAutoMode(!autoMode)}
                  className={`text-xs font-semibold px-2 py-1 rounded-full transition-all 
                  ${autoMode
                      ? "bg-gradient-to-r from-[#ffd85a] to-[#42e2b8] text-[#1b1b1d] shadow-md"
                      : "bg-transparent text-[#fffaf2] border border-[#ffd85a]/40 hover:bg-[#ffd85a]/20"
                    }`}
                >
                  {autoMode ? "Auto" : "Manual"}
                </button>

                <div className="flex gap-2">
                  {Object.entries(icons).map(([key, icon]) => (
                    <button
                      key={key}
                      onClick={() => switchTheme(key)}
                      className={`text-xl transition-all transform 
                      ${theme === key
                          ? "scale-125 text-[#ffd85a] drop-shadow-[0_0_8px_rgba(255,216,90,0.6)]"
                          : "opacity-70 hover:opacity-100 text-white"
                        }`}
                      title={key}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

        </>
      )}
    </AnimatePresence>
  );
}
