import { useEffect, useState } from "react";
import api from "../services/api";   // OJO: debe usar tu instancia axios con token

export function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function check() {
      try {

        // ✔️ ESTE ES EL ENDPOINT CORRECTO
        const res = await api.get("/auth/me/");
        setUser(res.data);

      } catch (e) {
        setUser(null);
      }
      setLoading(false);
    }

    check();
  }, []);

  return { user, loading };
}
